export const PROFILE_DATA = {
  discord: {
    id: "389146146608513025", // Replace with your actual Discord ID
    username: "Lord",
    global_name: "Lord",
    avatar: "https://cdn.discordapp.com/embed/avatars/2.png",
    banner: null,
    accent_color: 5814783,
  },
  instagram: {
    username: "lordx679",
    profile_pic: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=150&h=150&fit=crop",
    biography: "Turning impossible ideas into reality.",
    followers_count: 1337,
  }
};
