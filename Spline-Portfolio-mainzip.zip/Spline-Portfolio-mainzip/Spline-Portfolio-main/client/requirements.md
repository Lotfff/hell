## Packages
@splinetool/react-spline | For rendering the 3D scene
@splinetool/runtime | Dependency for Spline
framer-motion | For smooth page transitions and scroll animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
